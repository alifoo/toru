// src/config.ts
var SERVER = true ? "https://mcp.toru.tools" : "https://mcp.toru.tools";
var VERSION = true ? "0.1.15" : "0.0.0";
var DEVELOPMENT = /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(SERVER);
var VIEWPORT_PRESETS = { "1280x720": { width: 1280, height: 720 }, "1440x900": { width: 1440, height: 900 }, "1920x1080": { width: 1920, height: 1080 } };
var DEFAULT_VIEWPORT = VIEWPORT_PRESETS["1920x1080"];
var LEGACY_VIEWPORT = VIEWPORT_PRESETS["1280x720"];
function chooseViewport(requested) {
  if (requested === void 0 || requested === null) return { ...LEGACY_VIEWPORT };
  const size = requested;
  const preset = Object.values(VIEWPORT_PRESETS).find((item) => item.width === size?.width && item.height === size?.height);
  return { ...preset ?? DEFAULT_VIEWPORT };
}
var CDP_COMMANDS = /* @__PURE__ */ new Set([
  "DOM.describeNode",
  "DOM.getBoxModel",
  "DOM.getFrameOwner",
  "Emulation.setDeviceMetricsOverride",
  "Input.dispatchKeyEvent",
  "Input.dispatchMouseEvent",
  "Page.captureScreenshot",
  "Page.enable",
  "Page.getFrameTree",
  "Page.getLayoutMetrics",
  "Page.navigate",
  "Runtime.enable",
  "Runtime.evaluate",
  "Page.startScreencast",
  "Page.stopScreencast",
  "Page.screencastFrameAck",
  "Page.bringToFront",
  // The privacy blur, installed on every document the recording opens (redactSensitiveText).
  "Page.addScriptToEvaluateOnNewDocument",
  "Page.removeScriptToEvaluateOnNewDocument"
]);

// src/placeholder.ts
var RECORDING_PLACEHOLDER = "data:text/html,<title>Toru recording</title>";

// src/background.ts
var offscreenUrl = chrome.runtime.getURL("offscreen.html");
var brain;
async function credentials() {
  return (await chrome.storage.local.get("credentials")).credentials;
}
async function sessions() {
  return (await chrome.storage.session.get("sessions")).sessions ?? [];
}
async function saveSessions(list) {
  await chrome.storage.session.set({ sessions: list });
}
async function setState(state) {
  await chrome.storage.session.set({ state });
  await chrome.action.setBadgeText({ text: state.state === "recording" ? "REC" : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#e5484d" });
}
async function ensureOffscreen() {
  if (!await credentials()) return;
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["BLOBS"],
    justification: "Talks to Toru and encodes the recording of the tab Toru opened into a video file."
  }).catch(() => void 0);
}
async function closeOffscreen() {
  if (await chrome.offscreen.hasDocument()) await chrome.offscreen.closeDocument().catch(() => void 0);
}
function deviceName() {
  const platform = navigator.userAgentData?.platform;
  return `Chrome${platform ? ` on ${platform === "macOS" ? "Mac" : platform}` : ""}`;
}
async function pair(code) {
  if (typeof code !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(code)) return { error: "pairing_code_invalid" };
  const response = await fetch(`${SERVER}/extension/pair`, {
    method: "POST",
    redirect: "error",
    headers: { "content-type": "application/json", "x-toru-extension-version": VERSION },
    body: JSON.stringify({ code, deviceName: deviceName() })
  }).catch(() => void 0);
  if (!response?.ok) return { error: response?.status === 401 ? "pairing_code_invalid" : "toru_unreachable" };
  const issued = await response.json();
  await chrome.storage.local.set({ credentials: issued });
  await closeOffscreen();
  await ensureOffscreen();
  return { paired: true, connectionId: issued.connectionId ?? issued.deviceId };
}
async function unpair() {
  const current = await credentials();
  if (current) {
    await fetch(`${SERVER}/extension/revoke`, { method: "POST", redirect: "error", headers: { authorization: `Bearer ${current.accessToken}` } }).catch(() => void 0);
  }
  await chrome.storage.local.remove("credentials");
  await closeOffscreen();
  for (const session of await sessions()) await closeSession(session.tabId);
  await setState({ state: "signed_out", at: Date.now() });
  return { unpaired: true };
}
async function recordingBounds(width, height) {
  const api = chrome.system?.display;
  const displays = api ? await api.getInfo().catch(() => []) : [];
  const enabled = displays.filter((item) => item.isEnabled !== false);
  const display = enabled.find((item) => !item.isPrimary) ?? enabled.find((item) => item.isPrimary);
  if (!display) return { width, height };
  const area = display.workArea;
  const w = Math.min(width, area.width), h = Math.min(height, area.height);
  return {
    width: w,
    height: h,
    left: Math.round(area.left + (area.width - w) / 2),
    top: Math.round(area.top + (area.height - h) / 2)
  };
}
function windowFor(viewport) {
  return { width: viewport.width + 16, height: viewport.height + 160 };
}
async function openSession(viewport) {
  const size = windowFor(viewport);
  const create = (bounds) => chrome.windows.create({ url: RECORDING_PLACEHOLDER, type: "normal", focused: true, ...bounds });
  const window = await create(await recordingBounds(size.width, size.height)).catch(() => create({ ...size })).catch(() => create({}));
  const tabId = window.tabs?.[0]?.id;
  try {
    await chrome.debugger.attach({ tabId }, "1.3");
  } catch (error) {
    await chrome.windows.remove(window.id).catch(() => void 0);
    throw new Error("extension_debugger_unavailable");
  }
  await chrome.tabs.setZoomSettings(tabId, { mode: "automatic", scope: "per-tab" }).catch(() => void 0);
  await chrome.tabs.setZoom(tabId, 1).catch(() => void 0);
  const session = { tabId, windowId: window.id };
  await saveSessions([...(await sessions()).filter((item) => item.tabId !== tabId), session]);
  return session;
}
async function closeSession(tabId) {
  const list = await sessions();
  const session = list.find((item) => item.tabId === tabId);
  await saveSessions(list.filter((item) => item.tabId !== tabId));
  await chrome.debugger.detach({ tabId }).catch(() => void 0);
  if (session) await chrome.windows.remove(session.windowId).catch(() => void 0);
}
async function handle(message) {
  switch (message.op) {
    case "credentials":
      return await credentials() ?? null;
    case "store": {
      if (message.credentials) await chrome.storage.local.set({ credentials: message.credentials });
      else {
        await chrome.storage.local.remove("credentials");
        setTimeout(() => void closeOffscreen(), 100);
      }
      return true;
    }
    case "state":
      await setState({ ...message.state, at: Date.now() });
      return true;
    case "ping":
      return true;
    case "zoom":
      return await chrome.tabs.getZoom(Number(message.tabId)).catch(() => null);
    case "reload":
      setTimeout(() => chrome.runtime.reload(), 100);
      return true;
    case "open":
      return await openSession(chooseViewport(message.viewport));
    case "close":
      await closeSession(Number(message.tabId));
      return true;
    case "release": {
      const tabId = Number(message.tabId);
      await saveSessions((await sessions()).filter((item) => item.tabId !== tabId));
      await chrome.debugger.detach({ tabId }).catch(() => void 0);
      return true;
    }
    case "send": {
      const tabId = Number(message.tabId);
      if (!(await sessions()).some((item) => item.tabId === tabId)) throw new Error("extension_tab_closed");
      if (!CDP_COMMANDS.has(message.method)) throw new Error("local_method_forbidden");
      return await chrome.debugger.sendCommand({ tabId }, message.method, message.params ?? {});
    }
    default:
      throw new Error("unknown_operation");
  }
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "toru-brain" || port.sender?.url !== offscreenUrl) {
    port.disconnect();
    return;
  }
  brain = port;
  port.onMessage.addListener((message) => {
    handle(message).then(
      (result) => port.postMessage({ reply: message.id, result }),
      (error) => port.postMessage({ reply: message.id, error: error instanceof Error ? error.message : "extension_failed" })
    );
  });
  port.onDisconnect.addListener(() => {
    if (brain === port) brain = void 0;
  });
});
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (!/^(Page\.(screencastFrame|loadEventFired|frameNavigated)|Runtime\.executionContext)/.test(method)) return;
  brain?.postMessage({ event: { tabId: source.tabId, method, params } });
});
chrome.debugger.onDetach.addListener((source, reason) => {
  void sessions().then(async (list) => {
    if (!list.some((item) => item.tabId === source.tabId)) return;
    await saveSessions(list.filter((item) => item.tabId !== source.tabId));
    brain?.postMessage({ detached: { tabId: source.tabId, reason } });
  });
});
chrome.tabs.onZoomChange.addListener((change) => {
  if (Math.abs(change.newZoomFactor - 1) < 1e-3) return;
  void sessions().then((list) => {
    if (list.some((item) => item.tabId === change.tabId)) void chrome.tabs.setZoom(change.tabId, 1).catch(() => void 0);
  });
});
chrome.windows.onRemoved.addListener((windowId) => {
  void sessions().then(async (list) => {
    const session = list.find((item) => item.windowId === windowId);
    if (!session) return;
    await saveSessions(list.filter((item) => item.windowId !== windowId));
    brain?.postMessage({ detached: { tabId: session.tabId, reason: "window_closed" } });
  });
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type === "toru-pair") {
    const from = typeof sender.url === "string" ? new URL(sender.url) : void 0;
    if (!from || from.origin !== SERVER || from.pathname !== "/extension/connect" || sender.id !== chrome.runtime.id) {
      reply({ error: "pairing_origin_invalid" });
      return false;
    }
    void pair(message.code).then(reply);
    return true;
  }
  if (sender.id !== chrome.runtime.id || sender.url?.startsWith(`${SERVER}/`)) return false;
  if (message?.type === "toru-pair-code") {
    void pair(String(message.code ?? "").trim()).then(reply);
    return true;
  }
  if (message?.type === "toru-unpair") {
    void unpair().then(reply);
    return true;
  }
  if (message?.type === "toru-status") {
    void Promise.all([credentials(), chrome.storage.session.get("state")]).then(([current, stored]) => reply({ paired: Boolean(current), connectionId: current?.connectionId ?? current?.deviceId ?? null, server: SERVER, version: VERSION, state: stored.state ?? null }));
    return true;
  }
  return false;
});
chrome.runtime.onStartup.addListener(() => void ensureOffscreen());
chrome.runtime.onInstalled.addListener(() => void ensureOffscreen());
chrome.alarms.create("toru-keepalive", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(() => void ensureOffscreen());
void ensureOffscreen();
