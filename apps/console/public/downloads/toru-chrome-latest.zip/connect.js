"use strict";
(() => {
  // src/connect.ts
  var statusLine = document.getElementById("toru-extension-status");
  var code = new URLSearchParams(location.hash.slice(1)).get("code");
  history.replaceState(null, "", location.pathname);
  var heading = document.getElementById("toru-extension-heading");
  var titles = { connecting: "Connecting\u2026", connected: "Chrome connected", failed: "Not connected", invalid: "Not connected" };
  var show = (state, text) => {
    if (statusLine) {
      statusLine.dataset.state = state;
      statusLine.textContent = text;
    }
    if (heading && titles[state]) heading.textContent = titles[state];
  };
  if (!code) show("invalid", "This link has no pairing code. Ask your agent for a new link.");
  else {
    show("connecting", "Connecting this Chrome to Toru\u2026");
    chrome.runtime.sendMessage({ type: "toru-pair", code }).then((reply) => {
      if (reply?.paired) show("connected", "Your agent can now record in this Chrome: Toru opens a new window for each recording. You can close this tab.");
      else if (reply?.error === "toru_unreachable") show("failed", "Toru could not be reached. Check your connection and open the link again.");
      else show("failed", "This link expired or was already used. Ask your agent for a new one.");
    }, () => show("failed", "The Toru extension did not answer. Reload this page."));
  }
})();
